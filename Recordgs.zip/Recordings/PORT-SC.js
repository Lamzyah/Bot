// WAJIB DI ISI AGAR BISA MENGGUNAKAN SCIRPT

const portip = {
  "ip": {
    "portsc": {
    "nama": "Botgerall", // NAMA TAPI GAK NGARUH SIH
    "idport": 8085, // BIARKAN DEFAULT ATAU UBAH GAPAPA
    "email": "botverifycode@gmail.com ", // EMAIL LU YANG AKTIF
    },          
},
};

module.exports = { portip }