let handler = async m => m.reply(`[ PRICELIST PANEL ]
Toko Name : Store.zxcoder
Admin : IchanZX

⬇️ List Harga Panel (Normal)  :
• 1gb 35% CPU 10K / Bulan
• 2gb 60% CPU 15K / Bulan
• 3gb 85% CPU 20K / Bulan
• 4gb 100% CPU 25K / Bulan
• 5gb 135% CPU 30K / Bulan
• 6gb 150% CPU 35K / Bulan
• 7gb 180% CPU 40K / Bulan

PAKET SPECIAL HOT 🔥

🔥 Paket Extra Normal
Unlimited = 30K/1 Bulan
🔥 Paket Extra Standar
Unlimited = 40K/2bulan
🔥 Paket Extra Hot SPECIAL
Unlimited = 50K/4bulan

ℹ️ Keuntungan Panel :
• On 24Jam Tanpa Henti
• Fast Respon
• No delay
• No ribet

🛍️ Keuntungan Belanja Di Store ZXcoderiD?
• Garansi 28hari
• Pelayanan Harga Murah
• Boleh Nego / Nyicil
• Terjamin Amanah & Aman

LOGIN PANEL :
- panel : https://tinyurl.com/zxcoderapk

𝗩𝗜𝗔 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡
➪ https://telegra.ph/file/2eef441d928e9e24c9037.jpg (QRIS)
➪ Gopay
➪ Dana
➪ Ovo
➪ Qris
➪ ShopeePay
➪ Bank (BCA)

Website :
https://website.zxcoderid.xyz

© 2023 Ichan Gaming
`.trim()) // Tambah sendiri kalo mau
handler.help = ['panel']
handler.tags = ['info']
handler.command = /^panel$/i

module.exports = handler