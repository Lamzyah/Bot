/*=========== GLOBAL CONFIG ===========*/
// SCRIPT BY ICHANZX ID
// SORRY MASIH PEMULA KALO CODE NYA CACAD XIXI
// @_fake.story46
/*=========== GLOBAL CONFIG ===========*/
let fs = require('fs') 
let chalk = require('chalk')

global.updatesc = true // false untuk mematikan autoUpdate SC

global.webapi = 'https://api.zxcoderid.my.id/' // JIKA ERROR Pesan ke Gmail > ichanzxcoderme@gmail.com
global.Apisichan = 'https://api.miftah.xyz'
// owner
global.namaowner = `Gerall`
global.nolu = '62882022376830'
global.nomorowner = '62882022376830'
global.namabot = 'Rallz'
global.owner = JSON.parse(fs.readFileSync('./database/owner.json')) // ubah nomor owner nya di database agar bisa addowner pake fitur
global.thumb2 = "https://telegra.ph/file/1df8858574ddb9a3634b8.mp4" //FILES HARUS DIBAWAH 5MB // HARUS BERUPA URL KALO PAKE FOTO ERORR NGEYEL FIX SENDIRI
global.intro = 'https://telegra.ph/file/ca3b7b5955d1d34b9b133.jpg'
global.fotobotnya = 'https://telegra.ph/file/76dac6b1c51affd5b249e.jpg' // tempat foto tampilan menu
let cover = [ 'https://telegra.ph/file/e561c6103d25b8f7164e8.jpg', 'https://telegra.ph/file/e8d3feee0e8f06b6620a0.jpg', 'https://telegra.ph/file/e49f5c34dcd0bd7946e9f.jpg'
]
global.thumb = pickRandom(cover);
global.qris = 'https://telegra.ph/file/c85898e6fef8f2639cf47.jpg' // QRIS PAYMENT LU MAU DANA / ORKUT
// BACA UNTUK MENJADIKAN FOTO JADI URL KIRIM .TOURL PADA BOT!!
global.wait = '––––––『 ⎔ 𝙇𝙤𝙖𝙙𝙞𝙣𝙜... 』––––––\n\n⚡Jangan Spam Ya Om'
global.mods = [] // Want some help?
global.prems = ['62882022376830'] // Premium user has unlimited limit
/*=========== Panel ===========*/
global.domain = 'https://ichanzx.zxcoderid.xyz' // Domain
global.apikey = 'ptla_z9cfq5qFHebbgPWNt0dlu9PUCgjtjwcPJhxixcDQKeO'; // Key PTLA
global.c_apikey = 'ptlc_Jga62bR6FXEF87FtBgLMZokjwUqMOXF9LtSJ4ep4EqH' // Key PTLC
global.eggs = '15'
global.locs = '1'

global.apikeyhost = ' ' // atlantich2h baca >> https://telegra.ph/NIH-TUTORIAL-BIAR-LU-DAPAT-CUAN-04-09
/*=========== store send testi ===========*/
global.jb1 = '120363183579741243' // ID GRUP LU CEK DI GROUPLIST
global.jb2 = '120363183579741243' // ID GRUP LU CEK DI GROUPLIST
/*=========== Harga reseller panel ===========*/
global.harga1gb = '10000'
global.harga2gb = '15000'
global.harga3gb = '20000'
global.harga4gb = '25000'
global.harga5gb = '30000'
global.harga6gb = '35000'
global.harga7gb = '40000'
global.hargaunli = '30000'
/*=========== Harga nokos wa ===========*/
global.nokosindo = '7000'
global.nokosusa = '8000'
global.nokosmalay = '12000'
global.apiotp = ' ' // api otp nokos lu
/*=========== HIASAN MENU ===========*/
global.dmenut = '❏═┅═━–〈' // atas
global.dmenub = '┊•' // badan
global.dmenub2 = '┊' // bada pada default prefix nya
global.dmenuf = '┗––––––––––✦' // akhiran body
global.hiasan = '꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷꒦'
global.cmenut = '––––––『' // Atas / atap
global.cmenuh = '』––––––' // Bawah body
global.cmenub = '┊☃︎ ' //body
global.cmenuf = '┗━═┅═━––––––๑\n' //footer
global.cmenua = '' //after
global.pmenus = '☃︎' //pembatas menu selector
global.htki = '––––『' 
global.htka = '』––––' 
global.lopr = 'Ⓟ'
global.lolm = 'Ⓛ'
global.htjava = '❃' 

// Sosial Media
global.sig = 'https://instagram.com/justrallz'
global.syt = 'https://youtube.com/@Gerall13'
global.sgh = 'https://github.com/Gerall09'
global.sgc = 'https://whatsapp.com/channel/0029VaEyQ9mJkK7G5UV2vP0Q'
global.swa = 'https://wa.me/+-'
global.swb = 'alamsyah-tkj.github.io'
global.snh = 'https://nhentai.net/g/365296/' //Make ini aja gausah di ganti.

// Pembayaran
global.pdana = '0882022376830'
global.povo = '-'
global.pgopay = '0882022376830'
global.pulsa = '0882022376830'
global.pulsa2 = '-'
global.psaweria = 'https://saweria.co/rallam'
global.ptrakteer = 'https://trakteer.id/'
global.psbuzz = 'https://socialbuzz.com/'

const spack = fs.readFileSync("lib/exif.json")
const stickerpack = JSON.parse(spack)
if (stickerpack.spackname == '') {
  var sticker_name = namabot
  var sticker_author = 'Rall'
} else {
  var sticker_name = stickerpack.spackname
  var sticker_author = stickerpack.sauthor
}
// Sticker WM
packname = sticker_name
author = sticker_author
wm = '© Rall'

Intervalmsg = 1800 //detik
multiplier = 1000 // Tinggi Level Up
/*============== API ==============*/
const { ichanzx } = require('./lib/IchanZX.js');
function updateAPIChan() {
  ichanzx()
    .then(response => {
      global.apichan = response;
    })
    .catch(error => {
    //  console.error('Error updating apichan:', error.response ? error.response.data : error.message);
    });
}
updateAPIChan();
setInterval(updateAPIChan, 60000);
/*============== API ==============*/
APIs = { // API Prefix
  // name: 'https://website'
  nrtm: 'https://nurutomo.herokuapp.com',
  xteam: 'https://api.xteam.xyz',
  zahir: 'https://zahirr-web.herokuapp.com',
  bcil: 'https://75.119.137.248:21587',
  neoxr: 'https://api.neoxr.eu.org/',
  zeks: 'https://api.zeks.me',
  gimez: 'https://masgimenz.my.id/',
  melcanz: 'https://melcanz.com',
  pencarikode: 'https://pencarikode.xyz',
  LeysCoder: 'https://leyscoders-api.herokuapp.com',
  restapi: 'https://x-restapi.herokuapp.com',
  erdwpe : 'https://api.erdwpe.com',
  males: 'https://malesin.xyz'
}

APIKeys = { // APIKey Here
  // 'https://website': 'apikey'
  'https://api.xteam.xyz': 'apikeyaine',
  'https://zahirr-web.herokuapp.com': 'zahirgans',
  'https://api.neoxr.eu.org/': 'jVEMyB2ITJ',
  'https://api.zeks.me': 'apikeyaine',
  'https://pencarikode.xyz': 'pais',
  'https://melcanz.com': 'ZZBk7EBb',
  'https://leyscoders-api.herokuapp.com': 'dappakntlll',
  'https://x-restapi.herokuapp.com': 'BETA',
}

//process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0

const file_exif = "lib/exif.json"
fs.watchFile(file_exif, () => {
  fs.unwatchFile(file_exif)
  console.log(chalk.redBright("Update 'exif.json'"))
  delete require.cache[file_exif]
  require('./lib/exif.json')
})
rpg = {
  emoticon(string) {
    string = string.toLowerCase()
    let emot = {
      level: '🧬',
limit: '🌌',
health: '❤️',
exp: '✉️',
money: '💵',
potion: '🥤',
diamond: '💎',
common: '📦',
uncommon: '🎁',
mythic: '🗳️',
legendary: '🗃️',
pet: '🎁',
trash: '🗑',
armor: '🥼',
sword: '⚔️',
pickaxe: '⛏️',
fishingrod: '🎣',
bow: '🏹',
wood: '🪵',
rock: '🪨',
string: '🕸️',
horse: '🐎',
cat: '🐈',
dog: '🐕',
fox: '🦊',
wolf: '🐺',
centaur: '🐎',
phoenix: '🦜',
dragon: '🐉',
petfood: '🍖',
iron: '⛓️',
gold: '👑',
emerald: '💚',
bibitmangga: '🌾',
bibitanggur: '🌾',
bibitjeruk: '🌾',
bibitpisang: '🌾',
bibitapel: '🌾',
mangga: '🥭',
anggur: '🍇',
jeruk: '🍊',
pisang: '🍌',
apel: '🍎',
ayam: '🐔',
kambing: '🐐',
sapi: '🐄',
kerbau: '🐃',
babi: '🐖',
harimau: '🐅',
banteng: '🐂',
monyet: '🐒',
babihutan: '🐗',
panda: '🐼',
gajah: '🐘',
buaya: '🐊',
orca: '🐋',
paus: '🐳',
lumba: '🐬',
hiu: '🦈',
ikan: '🐟',
lele: '🐟',
bawal: '🐡',
nila: '🐠',
kepiting: '🦀',
lobster: '🦞',
gurita: '🐙',
cumi: '🦑',
udang: '🦐',
steak: '🍝',
sate: '🍢',
rendang: '🍜',
kornet: '🥣',
nugget: '🍱',
bluefin: '🍲',
seafood: '🍛',
sushi: '🍣',
moluska: '🥘',
squidprawm: '🍤',
rumahsakit: '🏥',
restoran: '🏭',
pabrik: '🏯',
tambang: '⚒️',
pelabuhan: '🛳️',
Fox: "🦊",
agility: "🤸‍♂️",
aqua: "🥤",
arc: "🏹",
bank: "🏦",
batu: "🧱",
berlian: "💎",
botol: "🍾",
bull: "🐃",
chicken: "🐓",
coal: "⚱️",
cow: "🐄",
crystal: "🔮",
darkcrystal: "♠️",
eleksirb: "🧪",
elephant: "🐘",
emasbatang: "🪙",
emasbiasa: "🥇",
gems: "🍀",
giraffe: "🦒",
griffin: "🦒",
healtmonster: "❤‍🔥",
intelligence: "🧠",
jeruk: "🍊",
kaleng: "🥫",
kardus: "📦",
kayu: "🪵",
ketake: "💿",
keygold: "🔑",
keyiron: "🗝️",
knife: "🔪",
koinexpg: "👛",
kucing: "🐈",
kyubi: "🦊",
lion: "🦁",
magicwand: "⚕️",
makanancentaur: "🥗",
makanangriffin: "🥙",
makanankyubi: "🍗",
makanannaga: "🍖",
makananpet: "🥩",
makananphonix: "🧀",
mana: "🪄",
money: "💵",
mythic: "🗳️",
mythic: "🪄",
naga: "🐉",
pancingan: "🎣",
petFood: "🍖",
phonix: "🦅",
pointxp: "📧",
rubah: "🦊",
sampah: "🗑️",
serigala: "🐺",
snake: "🐍",
stamina: "⚡",
strength: "🦹‍♀️",
superior: "💼",
tiger: "🐅",
tiketcoin: "🎟️",
umpan: "🪱",
upgrader: "🧰"

    }
    let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
    if (!results.length) return ''
    else return emot[results[0][0]]
  }
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})

function pickRandom(list) {
    return list[Math.floor(list.length * Math.random())];
}